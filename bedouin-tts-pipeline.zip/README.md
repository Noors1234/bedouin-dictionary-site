# Bedouin TTS Pipeline
واجهة عربية + Pipeline لجمع وتحليل الصوتيات البدوية
